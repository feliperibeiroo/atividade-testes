import React from 'react';
import { View, Text, TextInput, ScrollView, StyleSheet } from 'react-native'; // Assegure-se de que 'Text' está importado
import { Card, Button } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import Header from './components/Header';
import Footer from './components/Footer';

export default function CadastroMedicoScreen() {
  const navigation = useNavigation(); // Hook para navegação

  return (
    <View style={styles.container}>
      {/* Header */}
      <Header
        name="Mariana Maia"
        position="Atendente"
        profileImageUrl="https://img.freepik.com/fotos-gratis/jovem-mulher-trabalhando-no-escritorio-com-laptop-e-fones-de-ouvido-na-parede-branca-atendimento-ao-cliente-e-call-center_231208-8601.jpg?w=1380&t=st=1724717085~exp=1724717685~hmac=c0df740124bfb9cd1c047f4c069f68c58dbf45ef00d76c6e66fda7765b8d3337"
      />

      {/* Formulário */}
      <ScrollView contentContainerStyle={styles.formContainer}>
        <Card style={styles.formCard}>
          <Card.Title
            title="Cadastro Médico"
            titleStyle={styles.formTitle}
            left={(props) => <Ionicons name="person-add" size={32} color="#FFF" />}
          />
          <Card.Content>
            <TextInput
              style={styles.input}
              placeholder="Nome"
              placeholderTextColor="#888"
            />
            {/* Botão de Submit */}
            <Button
              mode="contained"
              style={styles.submitButton}
              onPress={() => navigation.navigate('CadastroSucesso')} // Navegar para CadastroSucesso
            >
              <Text style={styles.submitButtonText}>Cadastrar Médico</Text>
            </Button>
          </Card.Content>
        </Card>
      </ScrollView>

      {/* Footer */}
      <Footer style={styles.footer}>
        <Text style={styles.footerText}>Footer Content</Text>
      </Footer>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#B7FAFE',
  },
  formContainer: {
    padding: 20,
  },
  formCard: {
    backgroundColor: '#5978E5',
    borderRadius: 10,
  },
  formTitle: {
    color: '#FFF',
  },
  input: {
    backgroundColor: '#FFF',
    color: '#888',
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 10,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#5978E5',
  },
  submitButton: {
    backgroundColor: '#2DAD2B',
    marginTop: 20,
  },
  submitButtonText: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#5978E5',
    padding: 10,
  },
});
