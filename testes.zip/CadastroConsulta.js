import React from 'react';
import { View, Text, TextInput, ScrollView, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { Appbar, Card, Button } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

export default function CadastroConsultaScreen() {
  const navigation = useNavigation(); // Hook de navegação

  return (
    <View style={styles.container}>
      {/* Barra Superior */}
      <Appbar.Header style={styles.appbar}>
        <View style={styles.headerContent}>
          <Image
            source={{ uri: 'https://img.freepik.com/fotos-gratis/jovem-mulher-trabalhando-no-escritorio-com-laptop-e-fones-de-ouvido-na-parede-branca-atendimento-ao-cliente-e-call-center_231208-8601.jpg?w=1380&t=st=1724717085~exp=1724717685~hmac=c0df740124bfb9cd1c047f4c069f68c58dbf45ef00d76c6e66fda7765b8d3337' }}
            style={styles.profileImage}
          />
          <View>
            <Text style={styles.name}>Mariana Maia</Text>
            <Text style={styles.position}>Atendente</Text>
          </View>
        </View>
      </Appbar.Header>

      {/* Formulário de Cadastro de Consulta */}
      <ScrollView contentContainerStyle={styles.formContainer}>
        <Card style={styles.formCard}>
          <Card.Title
            title="Cadastro de Consulta"
            titleStyle={styles.formTitle}
            left={(props) => <Ionicons name="calendar" size={32} color="#FFF" />}
          />
          <Card.Content>
            <TextInput style={styles.input} placeholder="Data" placeholderTextColor="#888" />
            <TextInput style={styles.input} placeholder="ID do Paciente" placeholderTextColor="#888" />
            <TextInput style={styles.input} placeholder="Médico" placeholderTextColor="#888" />
            <TextInput style={styles.input} placeholder="Hora" placeholderTextColor="#888" />
            <TextInput style={styles.input} placeholder="Observações" placeholderTextColor="#888" multiline />

            {/* Botão de Submit */}
            <Button
              mode="contained"
              style={styles.submitButton}
              onPress={() => navigation.navigate('CadastroSucesso')} // Navegação para CadastroSucesso
            >
              <Text style={styles.submitButtonText}>Cadastrar Consulta</Text>
            </Button>
          </Card.Content>
        </Card>
      </ScrollView>

      {/* Rodapé */}
      <View style={styles.footer}>
        <TouchableOpacity onPress={() => { /* Implementar a ação de voltar aqui */ }}>
          <Ionicons name="arrow-back" size={32} color="#FFF" />
        </TouchableOpacity>
        <Image
          source={{ uri: 'https://img.freepik.com/vetores-gratis/hospital-logo-design-vector-medical-cross_53876-136743.jpg?size=338&ext=jpg&ga=GA1.1.2008272138.1723939200&semt=ais_hybrid' }}
          style={styles.footerImage}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#B7FAFE',
  },
  appbar: {
    backgroundColor: '#5978E5',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  profileImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  name: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  position: {
    color: '#FFF',
    fontSize: 14,
  },
  formContainer: {
    padding: 20,
  },
  formCard: {
    backgroundColor: '#5978E5',
    borderRadius: 10,
  },
  formTitle: {
    color: '#FFF',
  },
  input: {
    backgroundColor: '#FFF',
    color: '#888',
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 10,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#5978E5',
  },
  submitButton: {
    backgroundColor: '#2DAD2B',
    marginTop: 20,
  },
  submitButtonText: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#5978E5',
    padding: 10,
  },
  footerImage: {
    width: 40,
    height: 40,
  },
});
