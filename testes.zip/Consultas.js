import React from 'react';
import { View, ScrollView, StyleSheet, TextInput, TouchableOpacity, Text } from 'react-native';
import { Button, Card } from 'react-native-paper';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import Header from './components/Header';
import Footer from './components/Footer';
import { useNavigation } from '@react-navigation/native';

export default function ConsultasScreen() {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      {/* Header */}
      <Header
        name="Mariana Maia"
        position="Atendente"
        profileImageUrl="https://img.freepik.com/fotos-gratis/jovem-mulher-trabalhando-no-escritorio-com-laptop-e-fones-de-ouvido-na-parede-branca-atendimento-ao-cliente-e-call-center_231208-8601.jpg?w=1380&t=st=1724717085~exp=1724717685~hmac=c0df740124bfb9cd1c047f4c069f68c58dbf45ef00d76c6e66fda7765b8d3337"
      />

      {/* Formulário de Consultas */}
      <ScrollView contentContainerStyle={styles.formContainer}>
        <Card style={styles.formCard}>
          <Card.Title
            title="Consultas"
            titleStyle={styles.formTitle}
            left={(props) => <MaterialCommunityIcons name="clipboard-text" size={32} color="#FFF" />}
          />
          <Card.Content>
            <TextInput style={styles.input} placeholder="Data" placeholderTextColor="#888" />
            <TextInput style={styles.input} placeholder="ID Paciente" placeholderTextColor="#888" />
            <TextInput style={styles.input} placeholder="Paciente" placeholderTextColor="#888" />
            <TextInput style={styles.input} placeholder="Médico" placeholderTextColor="#888" />

            {/* Botões */}
            <View style={styles.buttonContainer}>
              <Button mode="contained" style={styles.clearButton} onPress={() => {}}>
                <Text style={styles.clearButtonText}>Limpar</Text>
              </Button>
              <Button mode="contained" style={styles.applyButton} onPress={() => {}}>
                <Text style={styles.applyButtonText}>Filtrar</Text>
              </Button>
            </View>
            <View style={styles.singleButtonContainer}>
              <Button
                mode="contained"
                style={styles.applyButton}
                onPress={() => navigation.navigate('CadastroConsulta')} // Navegar para CadastroConsulta
              >
                <Text style={styles.applyButtonText}>Cadastrar Consulta</Text>
              </Button>
            </View>
          </Card.Content>
        </Card>

        {/* Tabela de Resultados */}
        <View style={styles.tableContainer}>
          <View style={styles.tableRow}>
            <Text style={styles.tableHeader}>Nome Pac</Text>
            <Text style={styles.tableHeader}>Hora</Text>
            <Text style={styles.tableHeader}>ID Med</Text>
            <View style={styles.tableActions}></View>
          </View>

          {/* Exemplo de Linha */}
          <View style={styles.tableRow}>
            <Text style={styles.tableCell}>João Paulo</Text>
            <Text style={styles.tableCell}>10:00</Text>
            <Text style={styles.tableCell}>001</Text>
            <View style={styles.tableActions}>
              <TouchableOpacity style={styles.actionButton}>
                <Ionicons name="pencil" size={24} color="#5978E5" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionButton}>
                <Ionicons name="print" size={24} color="#5978E5" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionButton}>
                <Ionicons name="trash" size={24} color="#5978E5" />
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>

      {/* Footer */}
      <Footer
        navigation={navigation}
        footerImageUrl="https://img.freepik.com/vetores-gratis/hospital-logo-design-vector-medical-cross_53876-136743.jpg?size=338&ext=jpg&ga=GA1.1.2008272138.1723939200&semt=ais_hybrid"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#B7FAFE',
  },
  formContainer: {
    flex: 1,
    padding: 20,
    paddingRight: 0,
  },
  formCard: {
    backgroundColor: '#5978E5',
    borderRadius: 10,
    padding: 15,
  },
  formTitle: {
    color: '#FFF',
    fontSize: 18,
  },
  input: {
    backgroundColor: '#FFF',
    color: '#888',
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 10,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#5978E5',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  singleButtonContainer: {
    marginTop: 10,
  },
  clearButton: {
    backgroundColor: '#A1A9A9',
    flex: 1,
    marginRight: 10,
  },
  applyButton: {
    backgroundColor: '#2DAD2B',
    flex: 1,
  },
  clearButtonText: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  applyButtonText: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  tableContainer: {
    marginTop: 30,
    borderWidth: 1,
    borderColor: '#5978E5',
    borderRadius: 10,
    padding: 15,
    backgroundColor: '#FFF',
  },
  tableRow: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    marginBottom: 10,
  },
  tableHeader: {
    flex: 0,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#5978E5',
    marginRight: 40,
  },
  tableCell: {
    flex: 1,
    fontSize: 14,
    color: '#333',
    marginRight: 10,
  },
  tableActions: {
    flexDirection: 'row',
  },
  actionButton: {
    marginLeft: 10,
  },
});
